"""Manufacturing sag tables from formal native BFSD/GetSag/SSLP queries."""
import math
from typing import Annotated,Literal
from pydantic import Field,model_validator
from .schema import Request,PositiveIndex,FiniteFloat
from .errors import ZemaxError

class SagTable(Request):
    kind: Literal['sag_table']
    surface: PositiveIndex
    minimum_radius: Annotated[FiniteFloat,Field(ge=0)] = 0
    maximum_radius: Annotated[FiniteFloat,Field(ge=0)] = 0
    samples: Annotated[int,Field(strict=True,ge=2,le=10001)] = 51

    @model_validator(mode='after')
    def range(self):
        if self.maximum_radius==0 and self.minimum_radius!=0:
            raise ValueError('自动半径范围要求minimum_radius与maximum_radius同时为0。')
        if self.maximum_radius and self.maximum_radius<=self.minimum_radius:
            raise ValueError('maximum_radius须大于minimum_radius。')
        return self

QUANTITIES=['curvature','radius','vertex_offset','maximum_removal_depth','removal_volume',
            'maximum_slope_difference','rms_removal_depth','rms_slope_difference']

def sphere_at(curvature,y):
    root=1-(curvature*y)**2
    if root<0:raise ZemaxError('INVALID_RESULT_DATA','BFS球面在请求半径处没有实数矢高。',curvature=curvature,y=y)
    root=math.sqrt(root)
    if root==0:raise ZemaxError('INVALID_RESULT_DATA','BFS球面在请求半径处斜率无限。',curvature=curvature,y=y)
    return curvature*y*y/(1+root),curvature*y/root

def run_sag_table(b,q):
    b._require_sequential();b._require_work()
    row=b._row(q.surface)
    lo=q.minimum_radius;hi=q.maximum_radius or float(row.SemiDiameter)
    if hi<=lo or not math.isfinite(hi):raise ZemaxError('INVALID_SETTING','有效半径范围必须正且递增。',minimum=lo,maximum=hi)
    native=b.native.api.Editors.MFE.MeritOperandType
    bfs=b.native.enum(native,'BFSD');slope=b.native.enum(native,'SSLP')
    def query(code,args,allow_infinite=False):
        try:value=float(b.system.MFE.GetOperandValue(code,*args))
        except Exception as exc:raise ZemaxError('NATIVE_ERROR','SagTable原生查询失败。',operand=str(code),arguments=args,native_exception=str(exc),native_exception_type=type(exc).__name__)from exc
        if allow_infinite and math.isinf(value):return None
        if not math.isfinite(value):raise ZemaxError('INVALID_RESULT_DATA','SagTable原生查询返回非有限值。',operand=str(code),arguments=args,value=str(value))
        return value
    def flow(task):
        unit=task['context']['lens_units'];summary={};args=[]
        task['payload']=dict(analysis_kind=q.kind,computation_method='native_BFSD_GetSag_SSLP',
            actual_settings=dict(request=q.model_dump(),effective_radius_range=[lo,hi],criterion='MinimumVolume',
                configuration=task['context']['configuration'],settings_source='explicit formal native query arguments'),
            units=dict(length=unit,slope='dimensionless',curvature='1/'+unit,volume=unit+'^3'),
            native_query_arguments=args,summary=summary,series=[],
            coordinate_definition='local surface coordinates x=0,y=positive radial coordinate; +z air to glass',
            resource_ownership='active system; no separate analysis/tool instance opened',
            slope_definition='native SSLP query slope; SagTable text uses finite-difference slopes and may differ near concave vertices',
            scope_status='MinimumVolume native operand path; dedicated SagTable dialog options/readback remain under investigation')
        for index,key in enumerate(QUANTITIES):
            b._cancel_boundary(task)
            parameters=[q.surface,index,lo,hi,0.,0.,0.,0.]
            summary[key]=query(bfs,parameters,allow_infinite=key=='radius')
            if key=='radius' and summary[key] is None:summary['radius_state']='infinite'
            args.append(dict(operand='BFSD',quantity=key,arguments=parameters))
            yield
        if summary['curvature']==0:summary['curvature_state']='planar'
        for i in range(q.samples):
            b._cancel_boundary(task);y=lo+(hi-lo)*i/(q.samples-1)
            try:ok,sag,alternate=b.system.LDE.GetSag(q.surface,0.,y)
            except Exception as exc:raise ZemaxError('NATIVE_ERROR','GetSag查询失败。',surface=q.surface,y=y,native_exception=str(exc))from exc
            if not ok or not math.isfinite(sag):raise ZemaxError('INVALID_RESULT_DATA','GetSag未返回有效矢高。',surface=q.surface,y=y,native_success=bool(ok),native_sag=str(sag))
            parameters=[q.surface,1,0.,y,0.,0.,0.,3.]
            actual_slope=query(slope,parameters)
            bfs_sag,bfs_slope=sphere_at(summary['curvature'],y)
            task['rows'].append(dict(index=i,y=y,sag=float(sag),bfs_sag=bfs_sag,deviation=float(sag)-bfs_sag,
                removal_depth=float(sag)-bfs_sag-summary['vertex_offset'],slope=actual_slope,bfs_slope=bfs_slope,
                slope_difference=actual_slope-bfs_slope,native_slope_arguments=parameters,state='succeeded'))
            yield
        for keys,label,units in [(['sag','bfs_sag'],'Sag',[unit,unit]),(['deviation','removal_depth'],'Removal',[unit,unit]),
                                  (['slope','bfs_slope','slope_difference'],'Slope',['dimensionless']*3)]:
            task['payload']['series'].append(dict(series=len(task['payload']['series']),description=label,
                labels=[key+' ('+units[j]+')' for j,key in enumerate(keys)],x_label='Local Y',x_unit=unit,
                value_units=units,x=[r['y'] for r in task['rows']],y=[[r[key] for key in keys] for r in task['rows']]))
    return b._composite(q.kind,q.model_dump(),flow)
