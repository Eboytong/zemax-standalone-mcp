"""Zemax Standalone MCP."""

__version__ = "0.1.61"

